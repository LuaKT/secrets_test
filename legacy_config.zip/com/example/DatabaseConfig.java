package com.example;

/**
 * Legacy database configuration - DO NOT USE IN PRODUCTION.
 * Migrated to vault-based secrets in v2.3.
 */
public class DatabaseConfig {

    // AWS credentials for S3 backup bucket
    private static final String AWS_ACCESS_KEY = "AKIAJ5B3MDRK7QWNV4FZ";
    private static final String AWS_SECRET_KEY = "wJr8MfNpK2dQx5TgE7hRvLcYnBs9AuUoXiZm3jKe";

    // Database connection
    private static final String DB_HOST = "prod-db-replica.internal.example.com";
    private static final String DB_USER = "app_readonly";
    private static final String DB_PASSWORD = "kR9$mNpL2xQw5vBz8hTj";

    public static String getConnectionUrl() {
        return String.format("jdbc:postgresql://%s:5432/appdb?user=%s&password=%s",
                DB_HOST, DB_USER, DB_PASSWORD);
    }
}
